# README --- Guia de revisão TP2 (C#)

Resumo para reconhecer o que cada enunciado pede e escolher a ferramenta
adequada.

## 1. LINQ --- consultar listas

  ---------------------------------------------------------------------------
  Método                     O que faz               Quando usar
  -------------------------- ----------------------- ------------------------
  `Where(...)`               Filtra elementos por    "Somente", "maior que",
                             condição.               "com nível acima de..."

  `Select(...)`              Seleciona ou transforma "Retorne apenas os
                             cada elemento.          nomes", "monte um
                                                     resultado".

  `OrderBy(...)`             Ordena em ordem         "Do menor para o maior",
                             crescente.              "ordem alfabética".

  `OrderByDescending(...)`   Ordena em ordem         "Do maior para o menor",
                             decrescente.            "mais perigoso
                                                     primeiro".

  `Take(n)`                  Pega os primeiros `n`   "Top 5", "as três
                             elementos.              maiores".

  `Count()`                  Conta elementos.        "Quantas ocorrências?"

  `Sum(...)`                 Soma valores numéricos. "Total dos
                                                     custos/valores".

  `Average(...)`             Calcula a média.        "Média dos
                                                     níveis/notas/valores".

  `Max(...)` / `Min(...)`    Retorna o maior/menor   "Maior nível", "menor
                             valor.                  custo".

  `Any(...)`                 Verifica se pelo menos  "Existe alguma
                             um elemento atende à    ocorrência...?"
                             condição.               

  `GroupBy(...)`             Agrupa elementos por    "Agrupe por
                             uma chave.              tipo/categoria/palco".

  `ToList()`                 Materializa o resultado Quando precisa de um
                             em uma lista.           `List<T>`.

  `FirstOrDefault(...)`      Retorna o primeiro      Quando o resultado pode
                             resultado ou valor      não existir.
                             padrão.                 
  ---------------------------------------------------------------------------

### Exemplos

``` csharp
var perigosas = investigacao.Ocorrencias
    .Where(o => o.NivelPerigo > 5);

var ranking = investigacao.Ocorrencias
    .OrderByDescending(o => o.NivelPerigo);

var topTres = investigacao.Ocorrencias
    .OrderByDescending(o => o.NivelPerigo)
    .Take(3);

bool existeNivelMaximo = investigacao.Ocorrencias
    .Any(o => o.NivelPerigo == 10);

double media = investigacao.Ocorrencias
    .Average(o => o.NivelPerigo);

var grupos = investigacao.Ocorrencias
    .GroupBy(o => o.GetType().Name);

foreach (var grupo in grupos)
{
    Console.WriteLine($"Tipo: {grupo.Key}");
    foreach (var ocorrencia in grupo)
        Console.WriteLine(ocorrencia.Descricao);
}
```

**Atenção:** `Average()` pode lançar exceção se a sequência estiver
vazia. `Where`, `OrderBy` e `Take` não imprimem resultados sozinhos; use
`foreach` para exibi-los.

Pistas do enunciado: - "Filtre", "somente" → `Where` - "Exiba apenas o
nome" → `Select` - "Do maior para o menor" → `OrderByDescending` - "Top
5" → `Take(5)` - "Some todos" → `Sum` - "Calcule a média" → `Average` -
"Existe algum?" → `Any` - "Agrupe por..." → `GroupBy` - "Quantos?" →
`Count`

## 2. Arquivos com `File`

  ------------------------------------------------------------------------------------------
  Método                                     O que faz               Quando usar
  ------------------------------------------ ----------------------- -----------------------
  `File.Exists(caminho)`                     Verifica se o arquivo   Antes de tentar
                                             existe.                 carregar um arquivo
                                                                     opcional.

  `File.ReadAllTextAsync(caminho)`           Lê todo o arquivo como  Para importar/ler o
                                             texto, assincronamente. JSON.

  `File.WriteAllTextAsync(caminho, texto)`   Grava texto no arquivo  Para exportar/salvar
                                             de forma assíncrona;    JSON.
                                             cria se necessário e    
                                             substitui o conteúdo    
                                             existente.              
  ------------------------------------------------------------------------------------------

``` csharp
if (File.Exists("ocorrencias.json"))
{
    string texto = await File.ReadAllTextAsync("ocorrencias.json");
}

await File.WriteAllTextAsync("ocorrencias.json", texto);
```

O nome pode ser direto (`"ocorrencias.json"`) ou guardado numa
variável/campo:

``` csharp
private string NomeArquivo = "ocorrencias.json";
```

Se usar `NomeArquivo`, declare-o num escopo válido, por exemplo dentro
da classe que contém os métodos de salvar e carregar.

## 3. JSON --- serialização e desserialização

-   `JsonSerializer.Serialize(objeto)`: objeto/lista → texto JSON.
-   `JsonSerializer.Deserialize<T>(texto)`: texto JSON → objeto/lista.

### Salvar/exportar

``` csharp
public async Task SalvarAsync()
{
    var options = new JsonSerializerOptions { WriteIndented = true };
    string json = JsonSerializer.Serialize(Ocorrencias, options);
    await File.WriteAllTextAsync(NomeArquivo, json);
}
```

`WriteIndented = true` deixa o JSON formatado para leitura.

### Carregar/importar

``` csharp
public async Task CarregarAsync()
{
    if (File.Exists(NomeArquivo))
    {
        string json = await File.ReadAllTextAsync(NomeArquivo);
        var listaCarregada = JsonSerializer.Deserialize<List<MinhaClasse>>(json);

        if (listaCarregada != null)
            MinhaLista = listaCarregada;
    }
}
```

-   `Exists`: verifica a existência do arquivo.
-   `ReadAllTextAsync`: lê o texto.
-   `Deserialize<List<MinhaClasse>>`: converte para lista.
-   `listaCarregada != null`: verifica que o resultado não é nulo.
-   `MinhaLista = listaCarregada`: substitui a lista atual.

**Atenção:** se a lista usa uma classe abstrata e subclasses (como
`Ocorrencia`, `ManifestacaoEspiritual` e `AnomaliaTemporal`),
desserializar para `List<Ocorrencia>` pode exigir configuração de
polimorfismo para preservar os tipos derivados.

## 4. `async`, `await` e `Task`

-   `async`: permite usar `await` no método.
-   `await`: aguarda a operação assíncrona terminar antes de continuar
    naquela sequência, sem bloquear a thread enquanto aguarda uma
    operação realmente assíncrona.
-   `Task`: representa uma operação assíncrona sem retorno de valor
    direto.
-   `Task<T>`: representa uma operação assíncrona que produzirá um valor
    do tipo `T`.
-   O sufixo `Async` é uma convenção de nome, não uma palavra-chave
    obrigatória.

``` csharp
public async Task SalvarAsync()
{
    string json = JsonSerializer.Serialize(Ocorrencias);
    await File.WriteAllTextAsync(NomeArquivo, json);
}
```

## 5. Delegate e evento

``` csharp
public delegate void OcorrenciaHandler(Ocorrencia o);
public event OcorrenciaHandler OcorrenciaPerigosa;
```

-   `delegate`: define a assinatura compatível dos métodos.
-   `event`: permite que outros objetos se inscrevam para receber
    notificações.
-   `+=`: associa um método ao evento.
-   `Invoke(o)`: chama os métodos inscritos e passa a ocorrência.
-   `?.`: evita chamar `Invoke` se não houver assinantes.

``` csharp
investigacao.OcorrenciaPerigosa += central.ExibirAlerta;
OcorrenciaPerigosa?.Invoke(o);
```

Declarar um evento não o dispara automaticamente: é preciso chamar
`Invoke` no momento apropriado.

`EventArgs` pode agrupar dados adicionais do evento. No padrão
`EventHandler<TEventArgs>`, normalmente há `sender` (quem disparou) e
`e` (os dados). Não é obrigatório em todo evento; siga o padrão do
enunciado.

## 6. Exceções --- `throw`, `try`, `catch`

``` csharp
public class OcorrenciaInvalidaException : Exception
{
    public OcorrenciaInvalidaException(string message) : base(message) { }
}
```

-   `: Exception`: faz a exceção personalizada herdar da classe base de
    exceções.
-   `throw`: lança a exceção.
-   `try`: envolve código que pode lançar uma exceção.
-   `catch`: trata a exceção compatível.
-   `ex.Message`: obtém a mensagem.

``` csharp
if (o.NivelPerigo < 0 || o.NivelPerigo > 10)
    throw new OcorrenciaInvalidaException("Nível inválido!");

try
{
    investigacao.RegistrarOcorrencia(o);
}
catch (OcorrenciaInvalidaException ex)
{
    Console.WriteLine($"Erro: {ex.Message}");
}
```

Em geral, o método que valida a regra lança a exceção; quem chama decide
como reagir. O `try/catch` precisa envolver a chamada que pode lançar o
erro.

## 7. Listas, objetos e chamadas de método

``` csharp
public List<Ocorrencia> Ocorrencias { get; set; } = new List<Ocorrencia>();
```

-   `List<T>`: lista de objetos.
-   `new List<T>()`: cria uma lista vazia.
-   `Add(item)`: adiciona.
-   `Remove(item)`: tenta remover.
-   `Count`: propriedade com a quantidade de elementos.
-   `ToList()`: cria uma lista a partir de uma sequência.

``` csharp
Investigacao investigacao = new Investigacao();
investigacao.RegistrarOcorrencia(o);
```

`Investigacao` é o tipo, `investigacao` é a variável e
`new Investigacao()` cria uma instância. Para chamar um método:
`objeto.Metodo(argumentos);`.

## 8. Checklist para a prova

-   [ ] Classes, propriedades e herança estão corretas?
-   [ ] O delegate tem os parâmetros certos?
-   [ ] O evento usa um delegate compatível?
-   [ ] O item é adicionado à lista?
-   [ ] O evento é disparado na condição solicitada?
-   [ ] O método assinante foi associado com `+=`?
-   [ ] A exceção personalizada herda de `Exception`?
-   [ ] A situação inválida usa `throw`?
-   [ ] A chamada que pode falhar está em `try/catch`?
-   [ ] A exportação usa `Serialize` e `WriteAllTextAsync`?
-   [ ] A importação verifica `File.Exists`, lê o arquivo e usa
    `Deserialize`?
-   [ ] A lista carregada é verificada antes de substituir a atual?
-   [ ] Os resultados LINQ são percorridos com `foreach` quando precisam
    ser exibidos?
-   [ ] Nomes de classes, propriedades e variáveis estão consistentes?

## Regra mental rápida

-   **Salvar:** lista → `Serialize` → texto JSON → `WriteAllTextAsync`.
-   **Carregar:** `File.Exists` → `ReadAllTextAsync` → texto JSON →
    `Deserialize` → substituir lista.
-   **Evento:** delegate → event → `+=` → `Invoke`.
-   **Exceção:** detectar situação inválida → `throw` → `try/catch`.
