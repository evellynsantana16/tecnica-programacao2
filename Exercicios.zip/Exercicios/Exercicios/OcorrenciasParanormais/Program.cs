﻿
/* Crie uma classe base Ocorrencia com as propriedades Descricao (string) e NivelPerigo (int).

Crie duas classes derivadas:
- ManifestacaoEspiritual, com a propriedade Intensidade (int).
- AnomaliaTemporal, com a propriedade DuracaoSegundos (int).
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;


// ==================== CÓDIGO PRINCIPAL ====================

// 1. Cria os objetos
Investigacao investigacao = new Investigacao();
CentralMonitoramento central = new CentralMonitoramento();

// 2. Inscreve o método no evento
investigacao.OcorrenciaPerigosa += central.ExibirAlerta;

// 3. Cria a ocorrência
// Instanciando o objeto
Ocorrencia o = new ManifestacaoEspiritual
{
    Descricao = "Ruídos inexplicáveis",
    NivelPerigo = 9,
    Intensidade = 8
};

// 4. Registra a ocorrência e trata possíveis erros
try
{
    // objeto.NomeDoMetodo(argumentos);
    investigacao.RegistrarOcorrencia(o);
}
catch (OcorrenciaInvalidaException ex)
{
    Console.WriteLine($"Erro: {ex.Message}");
}

// 5. LINQ: gera o relatório das ocorrências registradas
/*
Esse LINQ filtra ocorrências com nível de perigo igual ou superior a 5,
ordena as mais perigosas primeiro e agrupa por tipo. Para cada grupo,
calcula quantidade, maior nível e média.
*/

var rankingPerigo = investigacao.Ocorrencias
    .Where(o => o.NivelPerigo >= 5)
    .OrderByDescending(o => o.NivelPerigo)
    .GroupBy(o => o.GetType().Name)
    .Select(grupo => new
    {
        Tipo = grupo.Key,
        Quantidade = grupo.Count(),
        MaiorNivel = grupo.Max(o => o.NivelPerigo),
        MediaPerigo = grupo.Average(o => o.NivelPerigo)
    });

foreach (var grupo in rankingPerigo)
{
    Console.WriteLine($"Tipo: {grupo.Tipo}");
    Console.WriteLine($"Quantidade: {grupo.Quantidade}");
    Console.WriteLine($"Maior nível: {grupo.MaiorNivel}");
    Console.WriteLine($"Média de perigo: {grupo.MediaPerigo:N2}");
    Console.WriteLine("--------------------------");
}

// 6. Salva as ocorrências no arquivo JSON
await investigacao.SalvarAsync();


// ==================== CLASSES DO PROJETO ====================

// 7. Classe base Ocorrencia
public abstract class Ocorrencia
{
    public string Descricao { get; set; }
    public int NivelPerigo { get; set; }
}

// 8. Classe derivada ManifestacaoEspiritual
public class ManifestacaoEspiritual : Ocorrencia
{
    public int Intensidade { get; set; }
}

// 9. Classe derivada AnomaliaTemporal
public class AnomaliaTemporal : Ocorrencia
{
    public int DuracaoSegundos { get; set; }
}

/* Crie uma classe Investigacao que possua uma lista de ocorrências
e um evento chamado OcorrenciaPerigosa. */

// 10. Delegate: define a assinatura do método associado ao evento
// Ocorrencia o: parâmetro que o método associado deverá receber.
public delegate void OcorrenciaHandler(Ocorrencia o);

// 11. Classe Investigacao
public class Investigacao
{
    private string NomeArquivo = "ocorrencias.json";

    public List<Ocorrencia> Ocorrencias { get; set; }
        = new List<Ocorrencia>();

    public event OcorrenciaHandler OcorrenciaPerigosa;

    // 12. Registra e valida a ocorrência
    public void RegistrarOcorrencia(Ocorrencia o)
    {
        if (o.NivelPerigo < 0 || o.NivelPerigo > 10)
        {
            throw new OcorrenciaInvalidaException("Nível inválido!");
        }

        Ocorrencias.Add(o);

        if (o.NivelPerigo > 7)
        {
            // Dispara o evento informando os ouvintes
            OcorrenciaPerigosa?.Invoke(o);
        }
    }

    // 13. Salva a lista em JSON
    public async Task SalvarAsync()
    {
        var listaOcorrencias = Ocorrencias.ToList();

        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        string json = JsonSerializer.Serialize(
            listaOcorrencias, options);

        // Salva as ocorrências no arquivo
        await File.WriteAllTextAsync(NomeArquivo, json);
    }

    // 14. Carrega os dados do arquivo JSON
    public async Task CarregarAsync()
    {
        if (File.Exists(NomeArquivo))
        {
            string json = await File.ReadAllTextAsync(NomeArquivo);

            var listaCarregada =
                JsonSerializer.Deserialize<List<Ocorrencia>>(json);

            if (listaCarregada != null)
            {
                Ocorrencias = listaCarregada;
            }
        }
    }
}

// 15. Central de monitoramento
// O método recebe a ocorrência e exibe um alerta no console.
public class CentralMonitoramento
{
    public void ExibirAlerta(Ocorrencia o)
    {
        Console.WriteLine(
            $"OCORRÊNCIA DETECTADA! Descrição: {o.Descricao} | Nível: {o.NivelPerigo}"
        );
    }
}

/* Crie uma exceção chamada OcorrenciaInvalidaException.

Ao registrar uma ocorrência com nível de perigo menor que 0 ou maior que 10,
lance essa exceção. Utilize try/catch para tratar o erro. */

// 16. Exceção personalizada
public class OcorrenciaInvalidaException : Exception
{
    public OcorrenciaInvalidaException(string message)
        : base(message)
    {
    }
}
