﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.WriteLine("---- FESTIVAL DE MÚSICA -----\n");

// Criando Palcos
Palco palcoPrincipal = new Palco ( 1, "Palco Sunset", 15000, false);
Palco palcoEletronico = new Palco(2, "Palco EletroOpen", 8000, true);

// Criando Shows (Show contendo atração de cada tipo: Banda e DJ)
Show show1 = new Show(101, new DateTime(2026, 11, 21, 22, 0, 0),
    palcoEletronico);

show1.AdicionarBanda(1, "The Code Rockers", 25000.00m, 4, 1500.00m);

show1.AdicionarDjSet(2, "DJ Byte", 10000.00m, true);

// Show em palco aberto à meia-noite (Gerará ConflitoDeHorarioException)
Show show2 = new Show(102, new DateTime(2026, 11, 22, 0, 0, 0), palcoEletronico);

show2.AdicionarDjSet(3, "DJ Null", 8000.00m, false );

// Show em palco coberto à meia-noite (Válido)
Show show3 = new Show(103, new DateTime(2026, 11, 22, 0, 0, 0), palcoPrincipal);

show3.AdicionarBanda(4, "Jazz Symphony", 30000.00m, 8, 2000.00m);

// Lista em memória com todos os shows
List<Show> listaShows = new List<Show> { show1, show2, show3 };

// Assinando o evento de início de show
foreach (var show in listaShows)
{
    show.ShowIniciado += AvisoShow.Aviso;
}

// Testando o IniciarShow (com tratamento de exceção)
Console.WriteLine("--- TESTANDO INÍCIO DOS SHOWS E EVENTOS ---");
foreach (var show in listaShows)
{
    try
    {
        Console.Write($"Tentando iniciar Show ID {show.Id} ({show.Palco.NomePalco}) às {show.HorarioInicio:HH:mm}... ");
        show.IniciarShow();
    }
    catch (ConflitoDeHorarioException ex)
    {
        Console.WriteLine($"\n[ALERTA] {ex.Message}");
    }
}

Console.WriteLine("\n--- CONSULTA LINQ: AGRUPAMENTO POR PALCO ---");
// Consulta LINQ para agrupar shows pelo NomePalco
var showsPorPalco = listaShows
    .GroupBy(s => s.Palco.NomePalco);

foreach (var grupo in showsPorPalco)
{
    Console.WriteLine($"\nPalco: {grupo.Key}");
    foreach (var show in grupo)
    {
        Console.WriteLine($"  -> Show ID: {show.Id} | Horário: {show.HorarioInicio:dd/MM/yyyy HH:mm}");
        foreach (var atracao in show.Atracoes)
        {
            Console.WriteLine($"     * Artista: {atracao.NomeArtista} ({atracao.GetType().Name}) | Cachê: R$ {atracao.CalcularCache():N2}");
        }
    }
}

// Salvando em JSON de forma assíncrona
Console.WriteLine("\n--- PERSISTÊNCIA DE DADOS ---");

var repositorio = new RepositorioFestival();
await repositorio.SalvarShowsAsync(listaShows);
Console.WriteLine("Shows salvos com sucesso no arquivo 'shows.json' dentro da pasta bin/debug/... do projeto de forma assíncrona!");
public class ConflitoDeHorarioException : Exception
{
    public ConflitoDeHorarioException(string message) : base(message) { }
}

public class ShowIniciadoEventArgs : EventArgs
{
    public string NomePalco { get; set; }
    public DateTime HoraInicio { get; set; }

    public ShowIniciadoEventArgs(string nomePalco, DateTime horaInicio)
    {
        NomePalco = nomePalco;
        HoraInicio = horaInicio;
    }
}

public abstract class Atracao
{
    public int Id { get; set; }
    public string NomeArtista { get; set; }
    public decimal CacheBase { get; set; }

    protected Atracao(int id, string nome, decimal cache)
    {
        Id = id;
        NomeArtista = nome;
        CacheBase = cache;
    }
    public abstract decimal CalcularCache();
}

public class Banda : Atracao
{
    public int NumeroIntegrantes { get; set; }
    public decimal AdicionalPorIntegrante { get; set; }

    public Banda(int id, string nome, decimal cache, int integrantes, decimal adicional):base(id, nome , cache) 
    {
        NumeroIntegrantes = integrantes;
        AdicionalPorIntegrante = adicional;
    }
    public override decimal CalcularCache()
    {
        return CacheBase + (NumeroIntegrantes * AdicionalPorIntegrante);
    }
}

public class DjSet : Atracao
{
    public bool ExigeEfeitosVisuais { get; set; }

    public DjSet(int id, string nome, decimal cache, bool efeitos) : base(id, nome, cache)
    {
        ExigeEfeitosVisuais = efeitos;
    }
    public override decimal CalcularCache()
    {
        decimal acrescimo = ExigeEfeitosVisuais ? 1000.00m : 0m;
        return CacheBase + acrescimo;
    }
}

public class Palco
{
    public int Id { get; set; }
    public string NomePalco { get; set; }
    public int CapacidadePessoas { get; set; }
    public bool EhPalcoAberto { get; set; }
    public Palco(int id, string nome, int capacidade, bool aberto)
    {
        Id = id;
        NomePalco = nome;
        CapacidadePessoas = capacidade;
        EhPalcoAberto = aberto;
    }
}

public class Show
{
    public int Id { get; set; }
    public DateTime HorarioInicio { get; set; }

    public Palco Palco { get; set; }

    public List<Atracao> Atracoes { get; set; } = new List<Atracao>();

    public Show(int id, DateTime horario, Palco palco)
    {
        Id =id;
        HorarioInicio = horario;
        Palco = palco;
    }
    public void AdicionarBanda(int id, string nomeArtista, decimal cacheBase, int numeroIntegrantes, decimal adicionalPorIntegrante)
    {
        // O Show cria a Banda (composição) e a adiciona ao seu escopo
        Banda novaBanda = new Banda(id, nomeArtista, cacheBase, numeroIntegrantes, adicionalPorIntegrante);
        Atracoes.Add(novaBanda);
    }

    public void AdicionarDjSet(int id, string nomeArtista, decimal cacheBase, bool exigeEfeitosVisuais)
    {
        // O Show cria o DJ (composição) e o adiciona ao seu escopo
        DjSet novoDj = new DjSet(id, nomeArtista, cacheBase, exigeEfeitosVisuais);
        Atracoes.Add(novoDj);
    }
    public event EventHandler<ShowIniciadoEventArgs> ShowIniciado;

    public void IniciarShow()
    {
        if (Palco.EhPalcoAberto && HorarioInicio.Hour == 0)
        {
            throw new ConflitoDeHorarioException("Problema com o show! Reagendar");
        }

        ShowIniciado?.Invoke(this, new ShowIniciadoEventArgs(Palco.NomePalco, HorarioInicio));
    }
}

public class RepositorioFestival
{
    private const string NomeArquivo = "shows.json";

    public async Task SalvarShowsAsync(List<Show> shows)
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        string jsonString = JsonSerializer.Serialize(shows, options);
        await File.WriteAllTextAsync(NomeArquivo, jsonString);
    }
}
public class AvisoShow()
{
    public static void Aviso(Object? sender, ShowIniciadoEventArgs e)
    {
        Console.WriteLine($"Ligar os sistemas de som e luzes do palco {e.NomePalco} às {e.HoraInicio:HH:mm}");
    }
}