﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

internal class Program
{
    private static async Task Main(string[] args)
    {
        Console.WriteLine("=== MULTAS DE TRÂNSITO ===\n");

        // Instanciando a Central
        CentralDeMultas central = new CentralDeMultas();

        // Assinante (Ouvinte) do evento MultaRegistrada
        central.MultaRegistrada += AvisoMulta.AvisoGrave;


        // Registrando multas de teste (incluindo valores acima e abaixo de 500)
        Console.WriteLine("--- REGISTRANDO MULTAS ---");
        await central.Registrar(new Multa { Placa = "ABC-1234", TipoInfracao = "Excesso de Velocidade", Valor = 250.00m, Data = DateTime.Now });
        await central.Registrar(new Multa { Placa = "XYZ-9876", TipoInfracao = "Passar com o Sinal Vermelho", Valor = 650.50m, Data = DateTime.Now });
        await central.Registrar(new Multa { Placa = "DEF-5678", TipoInfracao = "Estacionar em Local Proibido", Valor = 150.00m, Data = DateTime.Now });
        await central.Registrar(new Multa { Placa = "GHI-4321", TipoInfracao = "Dirigir Utilizando o Celular", Valor = 890.00m, Data = DateTime.Now });

        // Consulta LINQ: Filtrar multas acima de determinado valor (ex: R$ 500,00)
        Console.WriteLine("\n--- CONSULTA LINQ: MULTAS ACIMA DE R$ 500,00 ---");
        decimal valorLimite = 500.00m;
        var multasFiltradas = central.Multas
            .Where(m => m.Valor > valorLimite)
            .OrderByDescending(m => m.Valor);

        foreach (var multa in multasFiltradas)
        {
            Console.WriteLine($"* Placa: {multa.Placa} | Infração: {multa.TipoInfracao} | Valor: R$ {multa.Valor:N2} | Data: {multa.Data:dd/MM/yyyy HH:mm}");
        }
    }
}

public class Multa
{
    public string Placa { get; set; }
    public string TipoInfracao { get; set; }
    public decimal Valor { get; set; }
    public DateTime Data { get; set; }
}

// Delegate exigido
public delegate void MultaHandler(Multa m);

public class CentralDeMultas
{
    public List<Multa> Multas { get; set; } = new List<Multa>();

    // Evento baseado no delegate MultaHandler
    public event MultaHandler MultaRegistrada;

    private const string NomeArquivo = "multas.json";

    public async Task Registrar(Multa m)
    {
        Multas.Add(m);
        if(m.Valor > 500.00m)
        {
            // Dispara o evento informando os ouvintes
            MultaRegistrada?.Invoke(m);
            //gravar no json
            
            await SalvarAsync();
            Console.WriteLine("Multa salva com sucesso no arquivo 'multas.json'!");

        }
        
    }

    // Método para salvar em JSON
    public async Task SalvarAsync()
    {
        var multasGraves = Multas.Where(x => x.Valor > 500.00m).ToList();

        var options = new JsonSerializerOptions { WriteIndented = true };
        string json = JsonSerializer.Serialize(multasGraves, options);

        // Salva as graves no arquivo
        await File.WriteAllTextAsync(NomeArquivo, json);

    }

    // Método para carregar de JSON (caso precise futuramente)
    public async Task CarregarAsync()
    {
        if (File.Exists(NomeArquivo))
        {
            string json = await File.ReadAllTextAsync(NomeArquivo);
            var listaCarregada = JsonSerializer.Deserialize<List<Multa>>(json);
            if (listaCarregada != null)
            {
                Multas = listaCarregada;
            }
        }
    }
}
public class AvisoMulta
{
    public static void AvisoGrave(Multa m)
    {
        Console.WriteLine($"MULTA GRAVE DETECTADA! Placa: {m.Placa} | Valor: R$ {m.Valor:N2}");
    }
    
}
