﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;


// ==================================================
// 1. CÓDIGO PRINCIPAL
// ==================================================

// 1.1. Cria a central responsável pelas missões.
CentralEspacial central = new CentralEspacial();

// 1.2. Cria o objeto responsável pelos alertas.
CentralDeMonitoramento monitoramento = new CentralDeMonitoramento();

// 1.3. Inscreve o método no evento.
// O += conecta o método ao evento.
central.MissaoPerigosa += monitoramento.ExibirAlerta;


// 1.4. Carrega as missões que já existem no arquivo.
await central.CarregarAsync();


// 1.5. Cria uma missão tripulada.
MissaoEspacial missao1 = new MissaoTripulada
{
    Nome = "Projeto Aurora",
    Destino = "Marte",
    NivelRisco = 9,
    QuantidadeAstronautas = 4
};

// 1.6. Cria uma missão robótica.
MissaoEspacial missao2 = new MissaoRobotica
{
    Nome = "Explorador Lunar",
    Destino = "Lua",
    NivelRisco = 6,
    TipoRobo = "Rover"
};

// 1.7. Cria outra missão robótica.
MissaoEspacial missao3 = new MissaoRobotica
{
    Nome = "Sonda Horizonte",
    Destino = "Júpiter",
    NivelRisco = 3,
    TipoRobo = "Sonda automática"
};


// 1.8. Registra as missões e trata possíveis erros.
try
{
    central.RegistrarMissao(missao1);
    central.RegistrarMissao(missao2);
    central.RegistrarMissao(missao3);
}
catch (MissaoInvalidaException ex)
{
    Console.WriteLine($"Erro: {ex.Message}");
}


// ==================================================
// 7. LINQ — RELATÓRIO DAS MISSÕES
// ==================================================

// 7.1. Filtra, ordena, agrupa e calcula estatísticas.
var ranking = central.Missoes
    .Where(m => m.NivelRisco >= 5)
    .OrderByDescending(m => m.NivelRisco)
    .GroupBy(m => m.GetType().Name)
    .Select(grupo => new
    {
        Tipo = grupo.Key,
        Quantidade = grupo.Count(),
        MaiorRisco = grupo.Max(m => m.NivelRisco),
        MediaRisco = grupo.Average(m => m.NivelRisco)
    });

// 7.2. Percorre os grupos e mostra o relatório.
Console.WriteLine("\n===== RELATÓRIO DE MISSÕES =====");

foreach (var grupo in ranking)
{
    Console.WriteLine($"Tipo: {grupo.Tipo}");
    Console.WriteLine($"Quantidade: {grupo.Quantidade}");
    Console.WriteLine($"Maior risco: {grupo.MaiorRisco}");
    Console.WriteLine($"Média de risco: {grupo.MediaRisco:N2}");
    Console.WriteLine("-------------------------------");
}

// 7.3. Verifica se existe alguma missão com risco máximo.
bool existeRiscoMaximo = central.Missoes
    .Any(m => m.NivelRisco == 10);

Console.WriteLine(
    existeRiscoMaximo
        ? "Existe missão com risco máximo!"
        : "Não existe missão com risco máximo."
);


// ==================================================
// 8. SALVAR OS DADOS
// ==================================================

// 8.1. Salva as missões no arquivo JSON.
await central.SalvarAsync();

Console.WriteLine("\nMissões salvas com sucesso.");


// ==================================================
// 2. CLASSE BASE E CLASSES DERIVADAS
// ==================================================

// 2.1. Permite preservar os tipos derivados no JSON.
// Recurso de System.Text.Json disponível em versões modernas do .NET.
[JsonPolymorphic(TypeDiscriminatorPropertyName = "tipo")]
[JsonDerivedType(typeof(MissaoTripulada), "tripulada")]
[JsonDerivedType(typeof(MissaoRobotica), "robotica")]
public abstract class MissaoEspacial
{
    public string Nome { get; set; } = string.Empty;
    public string Destino { get; set; } = string.Empty;
    public int NivelRisco { get; set; }
}

// 2.2. Classe derivada: missão tripulada.
public class MissaoTripulada : MissaoEspacial
{
    public int QuantidadeAstronautas { get; set; }
}

// 2.3. Classe derivada: missão robótica.
public class MissaoRobotica : MissaoEspacial
{
    public string TipoRobo { get; set; } = string.Empty;
}


// ==================================================
// 3 E 4. DELEGATE E CENTRAL ESPACIAL
// ==================================================

// 4.1. Define a assinatura dos métodos associados ao evento.
public delegate void MissaoHandler(MissaoEspacial missao);


// ==================================================
// 3, 5 E 8. CENTRAL ESPACIAL
// ==================================================

public class CentralEspacial
{
    // 8.2. Nome do arquivo que guarda as missões.
    private string NomeArquivo = "missoes.json";

    // 3.1. Lista que guarda as missões registradas.
    public List<MissaoEspacial> Missoes { get; set; }
        = new List<MissaoEspacial>();

    // 3.2. Evento para avisar quando uma missão é perigosa.
    public event MissaoHandler? MissaoPerigosa;


    // 5.1 E 6.1. Valida, registra e pode disparar o evento.
    public void RegistrarMissao(MissaoEspacial missao)
    {
        if (missao.NivelRisco < 1 || missao.NivelRisco > 10)
        {
            throw new MissaoInvalidaException(
                "O risco deve estar entre 1 e 10."
            );
        }

        // Adiciona a missão à lista.
        Missoes.Add(missao);

        // Dispara o evento se o risco for igual ou superior a 8.
        if (missao.NivelRisco >= 8)
        {
            MissaoPerigosa?.Invoke(missao);
        }
    }


    // 8.3. Converte a lista para JSON e grava o arquivo.
    public async Task SalvarAsync()
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        string json = JsonSerializer.Serialize(Missoes, options);

        await File.WriteAllTextAsync(NomeArquivo, json);
    }


    // 8.4. Lê o arquivo e reconstrói a lista.
    public async Task CarregarAsync()
    {
        if (File.Exists(NomeArquivo))
        {
            string json = await File.ReadAllTextAsync(NomeArquivo);

            var listaCarregada =
                JsonSerializer.Deserialize<List<MissaoEspacial>>(json);

            if (listaCarregada != null)
            {
                Missoes = listaCarregada;
            }
        }
    }
}


// ==================================================
// 6. CENTRAL DE MONITORAMENTO
// ==================================================

public class CentralDeMonitoramento
{
    // 6.2. Método inscrito no evento.
    public void ExibirAlerta(MissaoEspacial missao)
    {
        Console.WriteLine(
            $"ALERTA! Missão: {missao.Nome} | " +
            $"Destino: {missao.Destino} | " +
            $"Risco: {missao.NivelRisco}"
        );
    }
}


// ==================================================
// 5. EXCEÇÃO PERSONALIZADA
// ==================================================

public class MissaoInvalidaException : Exception
{
    public MissaoInvalidaException(string message)
        : base(message)
    {
    }
}
